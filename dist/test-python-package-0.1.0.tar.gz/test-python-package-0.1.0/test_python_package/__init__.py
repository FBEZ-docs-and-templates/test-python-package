__version__ = '0.1.0'


def greet(name):
    return f"Hello, {name}!"
