# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['test_python_package']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'test-python-package',
    'version': '0.1.0',
    'description': 'A greeting package',
    'long_description': None,
    'author': 'Francesco Bez',
    'author_email': 'francesco.bez@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/FBEZ-docs-and-templates/test-python-package',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
